from django.shortcuts import render,HttpResponseRedirect
from .models import *
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.messages import error,success
from django.contrib.auth.decorators import login_required 
# Create your views here.

def homePage(request):
    return render(request,'index.html')


def signupPage(request):
    if request.method == 'POST':
        password = request.POST.get('password')
        cpassword = request.POST.get('cpassword')
        if password==cpassword:           
         fullname = request.POST.get('fullname')
         username = request.POST.get('username')
         email = request.POST.get('email') 
        
         try:
          User.objects.create_user(username=username,password=password,email=email,first_name=fullname)
          s = Student_profile()
          s.name = fullname
          s.email_id = email
          s.username = username
          s.save()
          return HttpResponseRedirect('/login/')

         except:
            error (request,'something went wrong')
         
        else:
           error(request,'password and confirm password are not matched')
    return render(request, 'signup.html')


def loginPage(request):
   if request.method=='POST':
      username = request.POST.get('username')
      password = request.POST.get('password')
      user = authenticate(username=username, password=password)
      if user!=None:
         login(request,user)
         return HttpResponseRedirect('/subject/')
      else:
         error(request,'Invalid username or Password')
      
   return render(request, 'login.html')

@login_required(login_url="/login/")
def subjectPage(request):
   subject = Subjects.objects.all()
   return render(request, 'subjects.html', {'subject': subject})

@login_required(login_url="/login/")
def examPage(request,id):
   subject = Subjects.objects.get(id=id)
   question = Question.objects.filter(sub_name = subject)
   return render(request, 'exam.html', {'subject': subject, 'question':question})

@login_required(login_url="/login/") #this is django inbuild decorater which insure that user is login. if they are not login the send to login/ page 
def resultPage(request,id):
   subject = Subjects.objects.get(id=id)
   subject_name = Subjects.objects.get(sub_name=subject.sub_name)
   question = Question.objects.filter(sub_name = subject_name)
   user = request.user
   student = Student_profile.objects.get(username = user.username)
   result = Result(username = student,sub_name=subject)  #error username= student.username .username nahi hota is me direct pura object jai ga 

   right_ans = 0
   wrong_ans = 0

   for i in question:
      answer = request.POST.get('option'+str(i.id))
      if answer==i.answers:
         right_ans+=1
      else:
         wrong_ans+=1
   # result.username=user.username
   result.right_ans=right_ans
   result.wrong_ans=wrong_ans
   result.points=right_ans
   result.save()
   return render(request, 'result.html', {'result' : result,"student":student})



def logoutpage(Request):
   logout(Request)
   return HttpResponseRedirect("/")


# urls.py




   
   
   


