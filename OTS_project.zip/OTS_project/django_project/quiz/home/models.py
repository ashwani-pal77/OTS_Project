from django.db import models

# Create your models here.


class basecom(models.Model):
    id = models.AutoField(primary_key=True)

class Student_profile(basecom):
    name = models.CharField(max_length=55)
    email_id = models.CharField(max_length=60)
    username = models.CharField(max_length= 55, unique=True)


    # 

# models.py in your Django app

class Subjects(basecom):
    sub_name = models.CharField(max_length=55)
    image = models.ImageField(upload_to='subjects/', blank=True, null=True)  # Ensure this line is present

    def __str__(self):
        return self.sub_name


class Question(basecom):
    questions = models.CharField(max_length=100)
    sub_name = models.ForeignKey(Subjects, on_delete=models.CASCADE)
    op1 = models.CharField(max_length=55)
    op2 = models.CharField(max_length=55)
    op3 = models.CharField(max_length=55)
    op4 = models.CharField(max_length=55)
    answers = models.CharField(max_length=55)
    marks = models.IntegerField(default=5)

class Result(basecom):
    username = models.ForeignKey(Student_profile, on_delete=models.CASCADE)
    sub_name = models.ForeignKey(Subjects, on_delete=models.CASCADE)
    right_ans = models.IntegerField()
    wrong_ans = models.IntegerField()
    points = models.IntegerField()





